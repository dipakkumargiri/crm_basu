@extends('layouts.auth')

@section('content')


    <div class="alert alert-success">
        {!! $message !!}
    </div>
@endsection
