<div class="form-group" >
    <label class="control-label">@lang('app.shippingAddress') </label>
    <textarea class="form-control" name="shipping_address" id="shipping_address" rows="5"></textarea>
</div>