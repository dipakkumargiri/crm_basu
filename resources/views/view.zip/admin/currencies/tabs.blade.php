<div class="white-box">
    <nav>
        <ul class="showClientTabs">
            <li class="currencySetting"><a href="{{ route('admin.currency.index') }}"> <span>@lang('modules.currencySettings.currencySetting')</span></a>
            </li>
            <li class="currencyFormatSetting"><a href="{{ route('admin.currency.currency-format') }}"> <span>@lang('modules.currencySettings.currenyFormatSetting')</span></a>
            </li>
        </ul>
    </nav>
</div>